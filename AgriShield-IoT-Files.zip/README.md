# AgriShield IoT – Smart Agriculture Monitoring System

AgriShield is a low-cost, dual-zone smart agriculture solution built using ESP32, GSM module (SIM800L), and a variety of sensors. It monitors both farm environment and grain storage, and sends real-time SMS alerts to farmers.

## Features
- Monitors temperature, humidity, gas levels (pesticide/CO2), rain, and vibration
- Sends SMS alerts for pest detection, rainfall, and grain spoilage
- Modular design for outdoor and indoor use
- Affordable and easy to set up

## Hardware Used
- ESP32 DevKit V1
- SIM800L GSM Module
- DHT22 (Temperature & Humidity)
- MQ135 (Gas sensor)
- Rain sensor
- Vibration sensor
- Soil moisture sensor (optional)
- IR sensor (optional wind alternative)

## License
This project is licensed under the MIT License.